<h1>Payment Failed</h1>
<p><?= esc($message) ?></p>
