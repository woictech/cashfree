<h1>Payment Successful</h1>
<p>Your Order ID: <?= esc($order_id) ?></p>