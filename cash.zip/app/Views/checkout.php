<form action="<?= base_url('create-order') ?>" method="post">
    <button type="submit">Pay with Cashfree</button>
</form>